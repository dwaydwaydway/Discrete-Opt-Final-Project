
In this folder we save the results of the computations of the Agg-Lin programs run on the instances produced for n1=1000, n2=15, funding=1 (30 instances in total), where n1 is the number of students and n2 is the number of colleges.

We save the logs in the folder Hystogram_Experiments_n1=1000, and in the files Hystogram_bars_fund=B.txt we save the ranking of the colleges in which students are assigned (B=0, 1, 30). We use the last information in these three files (which is the average of the 30 instances) to plot the Histogram.